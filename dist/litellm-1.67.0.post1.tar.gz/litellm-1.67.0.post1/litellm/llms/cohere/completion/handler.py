"""
Cohere /generate API - uses `llm_http_handler.py` to make httpx requests

Request/Response transformation is handled in `transformation.py`
"""
