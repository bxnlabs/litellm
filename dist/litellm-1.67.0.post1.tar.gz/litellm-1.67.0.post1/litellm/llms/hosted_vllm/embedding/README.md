No transformation is required for hosted_vllm embedding.

VLLM is a superset of OpenAI's `embedding` endpoint.

To pass provider-specific parameters, see [this](https://docs.litellm.ai/docs/completion/provider_specific_params)