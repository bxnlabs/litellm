"""
Calls handled in openai/

as mistral is an openai-compatible endpoint.
"""
