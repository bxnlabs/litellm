from litellm.llms.base_llm.chat.transformation import BaseLLMException


class OpenRouterException(BaseLLMException):
    pass
