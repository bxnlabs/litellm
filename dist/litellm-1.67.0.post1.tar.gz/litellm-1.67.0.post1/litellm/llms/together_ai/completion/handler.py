"""
Uses openai's `/completion` handler.py
"""
