# Vertex AI Batch Prediction Jobs

Implementation to call VertexAI Batch endpoints in OpenAI Batch API spec

Vertex Docs: https://cloud.google.com/vertex-ai/generative-ai/docs/multimodal/batch-prediction-gemini

